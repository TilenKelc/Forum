<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>BlogIt - Api specs</title>
    </head>
    <body class="font-sans antialiased">
        <div id="swagger-api"></div>
        <script src="<?php echo e(mix('js/swagger.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Forum\resources\views/swagger/index.blade.php ENDPATH**/ ?>