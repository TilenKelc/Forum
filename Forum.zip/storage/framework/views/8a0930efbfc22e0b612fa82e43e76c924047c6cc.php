<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight" id="header-txt">
            Viewing your posts
        </h2>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-validation-errors','data' => ['errors' => $errors]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if(count($posts) != 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-4">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <!-- hover:bg-blue-600 hover:scale-200 transition duration-150 ease-in-out -->
                    <div class="flex pt-6 px-6">
                        <div class="w-1/2 underline text-sm italic text-gray-800 leading-tight">
                            <?php echo e($post->getUser()->username); ?>

                        </div>
                        <div class="w-1/2 text-right">
                            <?php echo e(date('d.m.Y h:i', strtotime($post->created_at))); ?>

                        </div>
                    </div>
                    <!--<div class="p-6 bg-white border-b border-gray-200">
                        asd
                    </div>-->
                    
                    <div class="px-6 pb-3 w-full border-b border-grey-200">
                        <h3 class="font-semibold text-lg text-gray-800 leading-tight mt-2 change-data"><?php echo e($post->title); ?></h3>
                    </div>
                    <div class="px-6 py-6 w-full">
                        <?php if(strlen($post->content) > 100): ?>
                            <?php echo e(substr($post->content, 0, 300)); ?>... <a href='<?php echo e(url("/post/show/$post->id")); ?>'>(Read more)</a>
                        <?php else: ?>
                            <?php echo e($post->content); ?>

                        <?php endif; ?>
                        <a href='<?php echo e(url("/post/show/$post->id")); ?>' class="underline text-sm italic">(Read more)</a>
                    </div>

                    <div class="px-6 pb-6 flex">
                        <div class="w-1/2 flex">
                            <?php if(Auth::check()): ?>
                                <?php if(Auth::user()->isBlocked()): ?>
                                    <svg class="w-6 h-6 dark:text-white md:text-xl cursor-pointer show-error-mssg" fill="<?php if($post->isUpvoted()){ echo 'grey'; } else { echo 'none'; } ?>" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z"></path></svg>
                                    <span class="px-2"><?php echo e($post->getlikes()); ?></span>
                                    <svg class="w-6 h-6 dark:text-white md:text-xl cursor-pointer show-error-mssg" fill="<?php if($post->isDownvoted()){ echo 'grey'; } else { echo 'none'; } ?>" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z"></path></svg>
                                <?php else: ?>
                                    <svg class="w-6 h-6 dark:text-white md:text-xl upvote cursor-pointer" id="<?php echo e($post->id); ?>" fill="<?php if($post->isUpvoted()){ echo 'grey'; } else { echo 'none'; } ?>" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z"></path></svg>
                                    <span class="px-2"><?php echo e($post->getlikes()); ?></span>
                                    <svg class="w-6 h-6 dark:text-white md:text-xl downvote cursor-pointer" id="<?php echo e($post->id); ?>" fill="<?php if($post->isDownvoted()){ echo 'grey'; } else { echo 'none'; } ?>" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z"></path></svg>
                                <?php endif; ?>
                            <?php else: ?>
                                <svg class="w-6 h-6 dark:text-white md:text-xl redirectBtn cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z"></path></svg>
                                <span class="px-2" id="post-likes"><?php echo e($post->getlikes()); ?></span>
                                <svg class="w-6 h-6 dark:text-white md:text-xl redirectBtn cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z"></path></svg>    
                            <?php endif; ?>
                        </div>
                        <div class="w-1/2 text-right">
                            <?php if(Auth::check() && Auth::id() == $post->user_id): ?>
                                <?php if(Auth::user()->isBlocked()): ?>
                                    <a href='javascript:void(0)' class="pr-2 cursor-pointer show-error-mssg">Edit</a>
                                    <a href='javascript:void(0)' class="cursor-pointer show-error-mssg">Delete</a>
                                <?php else: ?>
                                    <a href='<?php echo e(url("/post/edit/$post->id")); ?>' class="pr-2 cursor-pointer">Edit</a>
                                    <a href='javascript:void(0)' class="cursor-pointer deleteBtn" id="<?php echo e($post->id); ?>">Delete</a>
                                <?php endif; ?>    
                            <?php else: ?>
                                <?php if(Auth::check() && Auth::user()->isAdmin()): ?>
                                    <a href='javascript:void(0)' class="cursor-pointer deleteBtn" id="<?php echo e($post->id); ?>">Delete</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-4">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="flex py-6 px-6">
                    <div class="font-semibold text-md text-gray-800 leading-tight mt-2 change-data">
                        You do not have any posts
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <script>
        $(document).ready(() => {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('.show-error-mssg').on('click', function(){
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'This action is not allowed, as your account is blocked!',
                });
            });

            $('.deleteBtn').on('click', function(){
                Swal.fire({
                    title: 'Are you sure, you want to delete this post?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!',
                }).then((result) => {
                    if (result.isConfirmed) {
                        let base_link = '<?php echo e(URL::to("/")); ?>';
                        let link = '/post/delete/' + this.id;

                        window.location = base_link + link;
                    }
                })
            });

            $('.upvote').on('click', function(){
                let btn = this;
                $.ajax({
                    method: "POST",
                    url: '<?php echo e(route("post.like")); ?>',
                    data: { id: this.id, like: 1}
                })
                .done(function(response){
                    if(response){
                        btn.parentElement.childNodes[3].innerText = response;
                        let downBtn = btn.parentElement.childNodes[5];
                        
                        if(btn.getAttribute('fill') == 'none'){
                            if(downBtn.getAttribute('fill') != 'none'){
                                downBtn.setAttribute('fill', 'none');
                            }
                            btn.setAttribute('fill', 'grey');
                        }else{
                            btn.setAttribute('fill', 'none');
                        }
                    }
                });
            });

            $('.downvote').on('click', function(){
                let btn = this;
                $.ajax({
                    method: "POST",
                    url: '<?php echo e(route("post.dislike")); ?>',
                    data: { id: this.id, like: 0}
                })
                .done(function(response){
                    if(response){
                        btn.parentElement.childNodes[3].innerText = response;
                        let upBtn = btn.parentElement.childNodes[1];
                        
                        if(btn.getAttribute('fill') == 'none'){
                            if(upBtn.getAttribute('fill') != 'none'){
                                upBtn.setAttribute('fill', 'none');
                            }
                            btn.setAttribute('fill', 'grey');
                        }else{
                            btn.setAttribute('fill', 'none');
                        }
                    }
                });
            });

            $('.redirectBtn').on('click', function(){
                window.location = "<?php echo e(url('/login')); ?>";
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Forum\resources\views/post/view.blade.php ENDPATH**/ ?>